# Lógica del cotizador
