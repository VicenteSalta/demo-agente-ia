# Lógica de envío de emails
